//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SampTarg.rc
//
#define IDC_COMPORT                     1009
#define IDC_BAUDRATE                    1010
#define IDC_IGNCODE                     1012
#define IDC_CACHEMEM                    1013
#define IDC_CACHE_DATA                  1013
#define IDC_CACHESFR                    1014
#define IDD_TSETUP                      5000
#define IDD_MODELESS                    5001
#define IDC_CACHE_XDATA                 5001
#define IDC_CACHE_CODE                  5002
#define IDD_FDSETUP                     5002
#define IDC_FLASH_ERASE                 5003
#define IDC_FLASH_PROGRAM               5004
#define IDB_LOAD                        5005
#define IDC_FLASH_VERIFY                5005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        5006
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         5006
#define _APS_NEXT_SYMED_VALUE           5000
#endif
#endif
