//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SampTarg.rc
//
#define IDD_MODAL                       1000
#define IDC_COMPORT                     1009
#define IDC_BAUDRATE                    1010
#define IDC_IGNCODE                     1012
#define IDC_CACHEMEM                    1013
#define IDC_CACHESFR                    1014
#define IDR_TEST                        1201
#define ID_TEST_MESSAGEBOX              2000
#define ID_TEST_MODAL                   2001
#define ID_TEST_MODELESS                2002
#define ID_TEST_CHECK                   2003
#define ID_TEST_UNCHECK                 2004
#define ID_TEST_VIEW                    2005
#define IDD_TSETUP                      5000
#define IDD_MODELESS                    5001
#define IDD_FORM                        5002
#define ID_TEST_EDIT                    32771
#define ID_TEST_FORM                    32772
#define ID_TEST_FORM_1                  32773
#define ID_TEST_FORM_2                  32774
#define ID_DEBUG_BREAKPOINTS            32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        5004
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         5000
#define _APS_NEXT_SYMED_VALUE           5000
#endif
#endif
